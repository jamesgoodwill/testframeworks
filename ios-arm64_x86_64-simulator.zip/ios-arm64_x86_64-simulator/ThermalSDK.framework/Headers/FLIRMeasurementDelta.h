//
//  FLIRMeasurementDelta.h
//  ThermalSDK
//
//  Created by FLIR on 2020-12-08.
//  Copyright © 2020 FLIR Systems. All rights reserved.
//

#pragma once

#import "FLIRMeasurementShape.h"
#import "FLIRThermalDelta.h"

NS_ASSUME_NONNULL_BEGIN

/** @brief Class representing a delta measurement type in the image. */
@interface FLIRMeasurementDelta : FLIRMeasurementShape

/**
 * @brief Thermal difference/delta value.
 */
- (FLIRThermalDelta * _Nullable)getDeltaValue:(out NSError * _Nullable * _Nullable)error;

/**
 * @brief Gets the first shape.
 */
- (FLIRMeasurementShape *)getMember1;

/**
 * @brief Gets the second shape.
 */
- (FLIRMeasurementShape *)getMember2;

/**
 * @brief Gets the first delta member type.
 */
- (DeltaMemberValueType)getMember1ValueType;

/**
 * @brief Gets the second delta member type.
 */
- (DeltaMemberValueType)getMember2ValueType;

/**
 * @brief Sets the first delta member.
 */
- (BOOL)setMember1:(FLIRMeasurementShape *)shape
              type:(DeltaMemberValueType)type
             error:(out NSError * _Nullable * _Nullable)error;

/**
 * @brief Sets the second delta member.
 */
- (BOOL)setMember2:(FLIRMeasurementShape *)shape
              type:(DeltaMemberValueType)type
             error:(out NSError * _Nullable * _Nullable)error;

@end

NS_ASSUME_NONNULL_END
