//
//  FLIRFusionTransformation.h
//  ThermalSDK
//
//  Created by FLIR on 2021-03-16.
//  Copyright © 2021 FLIR Systems. All rights reserved.
//

#pragma once

NS_ASSUME_NONNULL_BEGIN

/** @brief Fusion transformation settings.  */
@interface FLIRFusionTransformation : NSObject

- (instancetype)initWithPanX:(int)panX panY:(int)panY scale:(float)scale rotation:(float)rotation;

/** @brief Fusion horizontal panning. */
@property (nonatomic, assign) int panX;
/** @brief Fusion vertical panning. */
@property (nonatomic, assign) int panY;
/** @brief Fusion zoom factor. */
@property (nonatomic, assign) float scale;
/** @brief Fusion rotation factor clockwise in degrees. */
@property (nonatomic, assign) float rotation;

@end

NS_ASSUME_NONNULL_END
